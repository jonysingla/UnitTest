//
//  util.swift
//  Flexyn
//
//  Created by day on 07/11/17.
//  Copyright © 2017 day. All rights reserved.
//

import Foundation


let Common_Domain = ""


