//
//  ViewController.swift
//  APIUnitTest
//
//  Created by Jony on 18/08/20.
//  Copyright © 2020 Jony. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
//        self.loginBtnAction()
    }

    
    func loginBtnAction() {
        let objLoginDataManager = LoginDataManager()
        objLoginDataManager.loginDataManager(phone_no: "9315396979", password: "123456", device_id: "eM1v-GRFnoY:APA91bEjQuJ5RrWAfLsKxRfL-KvYW0fXQmPdrrbyAx5LpOCHr_Cdt6SNrp4mOjCOrGPEoy4ctj1upwApuoSZ-wMhhTlu-RsdVB-uJntcG-3S-O7mv-0DB9mwLg24IK9RSbfrBDky5gDk", device_type: "android", callBack: {(isSuccess, errorMesssage)   in
            let strErrorMsg = errorMesssage
            let status = isSuccess
            if(status) {
                print("status ------------", status)
            } else {
                print("Error", strErrorMsg ?? "jony errorMesssage")
            }
        })
    }
}

