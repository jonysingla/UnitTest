//
//  LoginDataManager.swift
//  Flexyn
//
//  Created by day on 06/11/17.
//  Copyright © 2017 day. All rights reserved.
//

import UIKit
import Alamofire

class LoginDataManager: NSObject {
    
    func loginDataManager(phone_no : String, password: String, device_id : String, device_type: String, callBack :
        @escaping ((_ isSuccess : Bool, _ Message : String?) -> ())) {
        let parameters: Parameters = [
            "phone_no":phone_no,
            "password":password,
            "device_id":device_id,
            "device_type":device_type,
        ]
        let headers: HTTPHeaders = [
            "Accept": "application/json"
        ]
        print(parameters)
        
        Alamofire.request(Common_Domain, method: .post, parameters: parameters).responseJSON { response in
            if let json = response.result.value {
                print("JSON: \(json)") // serialized json response
                
                let statusCode = response.response?.statusCode
                print(statusCode as Any)
                if (statusCode == 200) {
                    if let json = response.result.value {
                        print("JSON: \(json)") // serialized json response
                        if let data = response.data, let _ = String(data: data, encoding: .utf8) {
                            callBack(true,"You are sucessfully Login")
                        }
                    }
                } else {
                    if let json = response.result.value {
                        print("JSON: \(json)") // serialized json response
                        if let data = response.data, let _ = String(data: data, encoding: .utf8) {
                            let dictionary = try? JSONSerialization.jsonObject(with: data, options: .mutableLeaves) as? NSDictionary
                            callBack(false,dictionary?.object(forKey: "error_description") as? String)
                        }
                    }
                }
            }
        }
    }
}
